#!/usr/bin/env python3
"""
cfc_experiment_runner_windows.py

Automates CFC tests with several xi values and seeds.

Usage, from the folder containing cfc_mock_universe_windows.py:

python cfc_experiment_runner_windows.py --grid 256 --seeds 1 2 3 --xis 0 0.015849 0.03

Heavy version:

python cfc_experiment_runner_windows.py --grid 512 --seeds 1 2 3 --xis 0 0.015849 0.03
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser(description="Run CFC multi-xi / multi-seed tests.")
    p.add_argument("--script", default="cfc_mock_universe_windows.py", help="Base mock script")
    p.add_argument("--outbase", default="cfc_experiments", help="Base output folder")
    p.add_argument("--grid", type=int, default=256, help="Grid resolution")
    p.add_argument("--seeds", nargs="+", type=int, default=[1, 2, 3], help="Random seeds")
    p.add_argument("--xis", nargs="+", type=float, default=[0.0, 0.015849, 0.03], help="Xi values")
    return p.parse_args()


def main():
    args = parse_args()
    script_path = Path(args.script)

    if not script_path.exists():
        raise FileNotFoundError(f"Script not found: {script_path}")

    outbase = Path(args.outbase)
    outbase.mkdir(parents=True, exist_ok=True)

    rows = []
    total = len(args.seeds) * len(args.xis)
    count = 0

    for seed in args.seeds:
        for xi in args.xis:
            count += 1
            xi_tag = str(xi).replace(".", "p").replace("-", "m")
            run_name = f"grid{args.grid}_xi{xi_tag}_seed{seed}"
            outdir = outbase / run_name
            outdir.mkdir(parents=True, exist_ok=True)

            cmd = [
                sys.executable,
                str(script_path),
                "--outdir", str(outdir),
                "--grid", str(args.grid),
                "--xi", str(xi),
                "--seed", str(seed),
            ]

            print(f"\n[{count}/{total}] Running xi={xi}, seed={seed}, grid={args.grid}")
            subprocess.run(cmd, check=True)

            meta_path = outdir / "metadata.json"
            if not meta_path.exists():
                print(f"WARNING: missing metadata for {run_name}")
                continue

            with open(meta_path, "r") as f:
                meta = json.load(f)

            meta["xi"] = xi
            meta["seed"] = seed
            meta["run_name"] = run_name
            meta["outdir"] = str(outdir)
            rows.append(meta)

    df = pd.DataFrame(rows)
    csv_path = outbase / "cfc_experiment_results.csv"
    df.to_csv(csv_path, index=False)

    cols = [
        "grid", "xi", "seed", "n_voids",
        "mean_abs_relative_delta_Pk",
        "max_abs_relative_delta_Pk",
        "mean_abs_local_cfc_correction",
        "max_abs_local_cfc_correction"
    ]
    print("\n=== RESULTS ===")
    print(df[cols].to_string(index=False))

    agg = df.groupby("xi").agg({
        "n_voids": ["mean", "std"],
        "mean_abs_relative_delta_Pk": ["mean", "std"],
        "max_abs_relative_delta_Pk": ["mean", "std"],
        "mean_abs_local_cfc_correction": ["mean", "std"],
        "max_abs_local_cfc_correction": ["mean", "std"],
    })
    agg_path = outbase / "cfc_experiment_summary_by_xi.csv"
    agg.to_csv(agg_path)

    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    for seed in sorted(df["seed"].unique()):
        d = df[df["seed"] == seed].sort_values("xi")
        ax.plot(d["xi"], d["mean_abs_local_cfc_correction"], "o-", alpha=0.75, label=f"seed {seed}")
    ax.set_xlabel("xi")
    ax.set_ylabel("mean |local CFC correction|")
    ax.set_title("CFC signal response to xi")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig_path = outbase / "xi_response.png"
    fig.savefig(fig_path, dpi=220)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    for xi in sorted(df["xi"].unique()):
        d = df[df["xi"] == xi].sort_values("seed")
        ax.plot(d["seed"], d["mean_abs_local_cfc_correction"], "o-", label=f"xi={xi:g}")
    ax.set_xlabel("seed")
    ax.set_ylabel("mean |local CFC correction|")
    ax.set_title("Seed-to-seed variability")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig2_path = outbase / "seed_variability.png"
    fig.savefig(fig2_path, dpi=220)
    plt.close(fig)

    print("\nSaved:")
    print(csv_path)
    print(agg_path)
    print(fig_path)
    print(fig2_path)


if __name__ == "__main__":
    main()

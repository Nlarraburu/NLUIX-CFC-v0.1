#!/usr/bin/env python3
"""
cfc_filtered_pk_analysis.py

Analyse filtrée des sorties CFC.

Lit un dossier contenant :
- Pk_comparison.csv
- metadata.json

Produit :
- Pk_comparison_filtered.csv
- filtered_analysis_summary.json
- figures_filtered/*.png

Exemple :
python cfc_filtered_pk_analysis.py --run C:/Users/nlarr/Documents/quijote_cfc_pipeline/cfc_mock_universe_fixed_512_xi005
"""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def parse_args():
    p = argparse.ArgumentParser(description="Filtered CFC P(k) analysis.")
    p.add_argument("--run", required=True, help="Run folder containing Pk_comparison.csv and metadata.json")
    p.add_argument("--kmax-fraction", type=float, default=0.75, help="Keep only k < fraction * max(k)")
    p.add_argument("--abs-cap", type=float, default=None, help="Optional: keep only |DeltaP/P| < abs-cap")
    return p.parse_args()


def main():
    args = parse_args()
    run = Path(args.run)
    figdir = run / "figures_filtered"
    figdir.mkdir(exist_ok=True)

    pk_path = run / "Pk_comparison.csv"
    meta_path = run / "metadata.json"

    if not pk_path.exists():
        raise FileNotFoundError(f"Missing file: {pk_path}")

    pk = pd.read_csv(pk_path)

    metadata = {}
    if meta_path.exists():
        with open(meta_path, "r") as f:
            metadata = json.load(f)

    kmax_raw = float(pk["k_h_mpc"].max())
    kmax_filter = args.kmax_fraction * kmax_raw

    mask = pk["k_h_mpc"] < kmax_filter

    if args.abs_cap is not None:
        mask = mask & (pk["relative_delta_Pk"].abs() < args.abs_cap)

    pk_filtered = pk[mask].copy()
    filtered_path = run / "Pk_comparison_filtered.csv"
    pk_filtered.to_csv(filtered_path, index=False)

    summary = {
        "run_folder": str(run),
        "grid": metadata.get("grid"),
        "xi": metadata.get("xi"),
        "n_voids": metadata.get("n_voids"),
        "kmax_raw": kmax_raw,
        "kmax_filter": kmax_filter,
        "kmax_fraction": args.kmax_fraction,
        "abs_cap": args.abs_cap,
        "n_bins_raw": int(len(pk)),
        "n_bins_filtered": int(len(pk_filtered)),
        "mean_abs_deltaPk_raw": float(pk["relative_delta_Pk"].abs().mean()),
        "max_abs_deltaPk_raw": float(pk["relative_delta_Pk"].abs().max()),
        "mean_abs_deltaPk_filtered": float(pk_filtered["relative_delta_Pk"].abs().mean()),
        "max_abs_deltaPk_filtered": float(pk_filtered["relative_delta_Pk"].abs().max()),
        "mean_abs_local_cfc_correction": metadata.get("mean_abs_local_cfc_correction"),
        "max_abs_local_cfc_correction": metadata.get("max_abs_local_cfc_correction"),
        "cfc_correction_std": metadata.get("cfc_correction_std"),
    }

    with open(run / "filtered_analysis_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(pk["k_h_mpc"], pk["relative_delta_Pk"], lw=1.2, alpha=0.45, label="raw")
    ax.plot(pk_filtered["k_h_mpc"], pk_filtered["relative_delta_Pk"], lw=2.0, label="filtered")
    ax.axhline(0, color="black", lw=0.8)
    ax.axvline(kmax_filter, color="gray", ls="--", lw=1, label="k filter")
    ax.set_xscale("log")
    ax.set_xlabel("k [h/Mpc]")
    ax.set_ylabel("Delta P(k) / P(k)")
    ax.set_title(f"Filtered CFC power response, xi={metadata.get('xi')}")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(figdir / "deltaPk_filtered.png", dpi=220)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(pk["k_h_mpc"], pk["relative_delta_Pk"].abs(), lw=1.2, alpha=0.45, label="raw abs")
    ax.plot(pk_filtered["k_h_mpc"], pk_filtered["relative_delta_Pk"].abs(), lw=2.0, label="filtered abs")
    ax.axvline(kmax_filter, color="gray", ls="--", lw=1)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("k [h/Mpc]")
    ax.set_ylabel("|Delta P/P|")
    ax.set_title("Absolute CFC spectral response")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(figdir / "abs_deltaPk_filtered.png", dpi=220)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.loglog(pk_filtered["k_h_mpc"], pk_filtered["Pk_LCDM"], lw=2, label="LCDM")
    ax.loglog(pk_filtered["k_h_mpc"], pk_filtered["Pk_CFC"], "--", lw=2, label="CFC")
    ax.set_xlabel("k [h/Mpc]")
    ax.set_ylabel("P(k)")
    ax.set_title("Filtered P(k) comparison")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(figdir / "Pk_comparison_filtered.png", dpi=220)
    plt.close(fig)

    print(json.dumps(summary, indent=2))
    print("\nSaved:")
    print(filtered_path)
    print(run / "filtered_analysis_summary.json")
    print(figdir / "deltaPk_filtered.png")
    print(figdir / "abs_deltaPk_filtered.png")
    print(figdir / "Pk_comparison_filtered.png")


if __name__ == "__main__":
    main()

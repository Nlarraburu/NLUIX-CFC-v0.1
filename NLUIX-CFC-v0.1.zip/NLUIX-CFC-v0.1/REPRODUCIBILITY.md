python cfc_mock_universe_windows_fixed.py --grid 512 --xi 0.05
python cfc_experiment_runner_windows.py --grid 512 --seeds 1 2 3 4 5 --xis 0.05
python cfc_filtered_pk_analysis.py --run <run_folder> --kmax-fraction 0.65

This repository presents an exploratory numerical experiment.
It is not a validated cosmological model and should not be interpreted as evidence for new physics.
# NLUIX-CFC

Exploration of an auxiliary field in a simplified cosmological simulation

Independent exploratory numerical study

Étude exploratoire indépendante menée par Nicolas Larraburu (NLUIX).

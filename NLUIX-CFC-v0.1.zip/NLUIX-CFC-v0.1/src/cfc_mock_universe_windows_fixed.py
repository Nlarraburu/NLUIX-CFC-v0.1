#!/usr/bin/env python3
"""
cfc_mock_universe_windows_fixed.py

Version corrigée du générateur CFC Windows.

Correction principale :
- suppression de la renormalisation fixe target_std = 4e-5 ;
- xi contrôle désormais réellement l'amplitude :
    cfc_correction = xi * laplacian(I)

Installation :
    python -m pip install numpy scipy pandas matplotlib

Exemple :
    python cfc_mock_universe_windows_fixed.py --outdir C:/Users/nlarr/Documents/quijote_cfc_pipeline/cfc_mock_universe_fixed --grid 256 --xi 0.015849
"""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter, label


def parse_args():
    p = argparse.ArgumentParser(description="Generate an autonomous CFC mock universe.")
    p.add_argument("--outdir", default="outputs/cfc_mock", help="Output folder")
    p.add_argument("--grid", type=int, default=128, help="3D grid size")
    p.add_argument("--boxsize", type=float, default=1000.0, help="Box size in Mpc/h")
    p.add_argument("--xi", type=float, default=0.015849, help="CFC coupling")
    p.add_argument("--smooth-density", type=float, default=4.0, help="Density smoothing in grid cells")
    p.add_argument("--smooth-I", type=float, default=3.0, help="I field smoothing in grid cells")
    p.add_argument("--void-quantile", type=float, default=0.22, help="Underdensity quantile for voids")
    p.add_argument("--min-void-cells", type=int, default=30, help="Minimum connected cells per void")
    p.add_argument("--seed", type=int, default=42, help="Random seed")
    return p.parse_args()


def laplacian_periodic(A, boxsize):
    n = A.shape[0]
    dx = boxsize / n
    return (
        np.roll(A, 1, axis=0) + np.roll(A, -1, axis=0)
        + np.roll(A, 1, axis=1) + np.roll(A, -1, axis=1)
        + np.roll(A, 1, axis=2) + np.roll(A, -1, axis=2)
        - 6.0 * A
    ) / dx**2


def power_spectrum_3d(delta, boxsize, nbins=48):
    n = delta.shape[0]
    dx = boxsize / n
    volume = boxsize**3

    dk = np.fft.fftn(delta)
    power = (np.abs(dk)**2) * (dx**6) / volume

    kfreq = 2 * np.pi * np.fft.fftfreq(n, d=dx)
    kx, ky, kz = np.meshgrid(kfreq, kfreq, kfreq, indexing="ij")
    kk = np.sqrt(kx**2 + ky**2 + kz**2)

    k_flat = kk.ravel()
    p_flat = power.ravel()

    mask = k_flat > 0
    k_flat = k_flat[mask]
    p_flat = p_flat[mask]

    bins = np.logspace(np.log10(k_flat.min()), np.log10(k_flat.max()), nbins + 1)
    which = np.digitize(k_flat, bins) - 1

    rows = []
    for i in range(nbins):
        m = which == i
        if not np.any(m):
            continue
        rows.append({
            "k_h_mpc": float(np.mean(k_flat[m])),
            "Pk0": float(np.mean(p_flat[m])),
            "Nmodes": int(np.sum(m))
        })
    return pd.DataFrame(rows)


def detect_voids(delta, boxsize, quantile=0.22, min_cells=30):
    n = delta.shape[0]
    dx = boxsize / n

    threshold = np.quantile(delta, quantile)
    mask = delta < threshold
    labels, nlabels = label(mask)

    rows = []
    for lab in range(1, nlabels + 1):
        region = labels == lab
        ncells = int(region.sum())
        if ncells < min_cells:
            continue

        coords = np.argwhere(region)
        centroid = coords.mean(axis=0) * dx
        volume = ncells * dx**3
        radius = (3 * volume / (4 * np.pi)) ** (1/3)

        rows.append({
            "void_id": len(rows),
            "x_mpc_h": float(centroid[0]),
            "y_mpc_h": float(centroid[1]),
            "z_mpc_h": float(centroid[2]),
            "radius_eff_mpc_h": float(radius),
            "volume_mpc_h3": float(volume),
            "n_grid_cells": ncells,
            "mean_delta": float(delta[region].mean()),
            "min_delta": float(delta[region].min()),
            "delta_threshold": float(threshold),
        })

    return pd.DataFrame(rows)


def save_slice(arr, outpath, title, cmap="viridis"):
    mid = arr.shape[2] // 2
    plt.figure(figsize=(6, 5))
    plt.imshow(arr[:, :, mid], cmap=cmap)
    plt.title(title)
    plt.axis("off")
    plt.colorbar(shrink=0.8)
    plt.tight_layout()
    plt.savefig(outpath, dpi=220)
    plt.close()


def main():
    args = parse_args()
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    figdir = outdir / "figures"
    figdir.mkdir(exist_ok=True)

    np.random.seed(args.seed)

    print("[1/8] Generating correlated density field...")
    white = np.random.normal(size=(args.grid, args.grid, args.grid))
    delta_raw = gaussian_filter(white, sigma=args.smooth_density)
    delta_raw = (delta_raw - delta_raw.mean()) / (delta_raw.std() + 1e-12)

    rho = np.exp(0.7 * delta_raw)
    rho = rho / rho.mean()
    delta = rho - 1.0

    print("[2/8] Building CFC scalar field I(x)...")
    I = 1.0 / (1.0 + np.clip(rho, 1e-8, None))
    I = gaussian_filter(I, sigma=args.smooth_I)
    I += 0.02 * gaussian_filter(np.random.normal(size=I.shape), sigma=2.0)
    I = (I - I.min()) / (I.max() - I.min() + 1e-12)

    print("[3/8] Computing CFC correction...")
    lapI = laplacian_periodic(I, args.boxsize)
    cfc_correction = args.xi * lapI

    delta_cfc = delta + cfc_correction

    print("[4/8] Computing power spectra...")
    pk_lcdm = power_spectrum_3d(delta, args.boxsize)
    pk_cfc = power_spectrum_3d(delta_cfc, args.boxsize)

    pk_lcdm.to_csv(outdir / "Pk_LCDM.csv", index=False)
    pk_cfc.to_csv(outdir / "Pk_CFC.csv", index=False)

    pk_compare = pk_lcdm.rename(columns={"Pk0": "Pk_LCDM"})[["k_h_mpc", "Pk_LCDM", "Nmodes"]]
    pk_compare["Pk_CFC"] = pk_cfc["Pk0"].values[:len(pk_compare)]
    pk_compare["relative_delta_Pk"] = (pk_compare["Pk_CFC"] - pk_compare["Pk_LCDM"]) / pk_compare["Pk_LCDM"]
    pk_compare.to_csv(outdir / "Pk_comparison.csv", index=False)

    print("[5/8] Detecting voids...")
    voids = detect_voids(delta, args.boxsize, args.void_quantile, args.min_void_cells)

    if len(voids):
        n = args.grid
        dx = args.boxsize / n
        signals = []
        for _, row in voids.iterrows():
            ix = int(np.clip(row.x_mpc_h / dx, 0, n - 1))
            iy = int(np.clip(row.y_mpc_h / dx, 0, n - 1))
            iz = int(np.clip(row.z_mpc_h / dx, 0, n - 1))
            signals.append(float(cfc_correction[ix, iy, iz]))
        voids["local_cfc_correction"] = signals

    voids.to_csv(outdir / "void_catalog_simple.csv", index=False)

    print("[6/8] Saving grids...")
    np.save(outdir / "delta_grid.npy", delta)
    np.save(outdir / "I_field.npy", I)
    np.save(outdir / "laplacian_I.npy", lapI)
    np.save(outdir / "cfc_correction.npy", cfc_correction)
    np.save(outdir / "delta_cfc_grid.npy", delta_cfc)

    print("[7/8] Generating figures...")
    save_slice(delta, figdir / "density_contrast_slice.png", "Density contrast delta", "magma")
    save_slice(I, figdir / "I_field_slice.png", "CFC scalar field I", "viridis")
    save_slice(cfc_correction, figdir / "cfc_correction_slice.png", "CFC correction", "coolwarm")

    plt.figure(figsize=(6.5, 4.2))
    plt.plot(pk_compare["k_h_mpc"], pk_compare["relative_delta_Pk"], lw=1.8, color="black")
    plt.axhline(0, color="gray", lw=1)
    plt.xscale("log")
    plt.xlabel("k [h/Mpc]")
    plt.ylabel("Delta P(k) / P(k)")
    plt.title("CFC modification of the matter power spectrum")
    plt.tight_layout()
    plt.savefig(figdir / "delta_Pk_over_Pk.png", dpi=220)
    plt.close()

    if len(voids):
        plt.figure(figsize=(6.2, 4))
        plt.hist(voids["radius_eff_mpc_h"], bins=40, color="gray", edgecolor="black", alpha=0.8)
        plt.xlabel("R_eff [Mpc/h]")
        plt.ylabel("count")
        plt.title("Void radius distribution")
        plt.tight_layout()
        plt.savefig(figdir / "void_radius_distribution.png", dpi=220)
        plt.close()

        plt.figure(figsize=(6.2, 4))
        plt.scatter(voids["radius_eff_mpc_h"], voids["local_cfc_correction"], s=14, alpha=0.6)
        plt.axhline(0, color="black", lw=1)
        plt.xlabel("R_eff [Mpc/h]")
        plt.ylabel("local CFC correction")
        plt.title("CFC signal around void centers")
        plt.tight_layout()
        plt.savefig(figdir / "void_cfc_signal.png", dpi=220)
        plt.close()

    print("[8/8] Writing metadata...")
    summary = {
        "script_version": "fixed_xi_controls_amplitude",
        "grid": args.grid,
        "boxsize_mpc_h": args.boxsize,
        "xi": args.xi,
        "density_smoothing_cells": args.smooth_density,
        "I_smoothing_cells": args.smooth_I,
        "n_voids": int(len(voids)),
        "laplacian_I_std": float(lapI.std()),
        "cfc_correction_std": float(cfc_correction.std()),
        "mean_abs_relative_delta_Pk": float(pk_compare["relative_delta_Pk"].abs().mean()),
        "max_abs_relative_delta_Pk": float(pk_compare["relative_delta_Pk"].abs().max()),
        "mean_abs_local_cfc_correction": float(voids["local_cfc_correction"].abs().mean()) if len(voids) else None,
        "max_abs_local_cfc_correction": float(voids["local_cfc_correction"].abs().max()) if len(voids) else None,
        "note": "Standalone Windows mock fixed; xi controls amplitude. Not an official Quijote/Euclid simulation."
    }

    with open(outdir / "metadata.json", "w") as f:
        json.dump(summary, f, indent=2)

    with open(outdir / "analysis_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("Done.")
    print(f"Outputs written to: {outdir}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
